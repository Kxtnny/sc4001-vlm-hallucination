"""Compare regenerated outputs (new results dir) with the reference results from the zip.

POPE: per-question answer agreement, metrics on the same questions, signal differences.
CHAIR: exact-caption agreement, shared token prefix, CHAIR metrics on the same images.
Attention: per-mention image-attention share differences (teacher forcing on the same captions).

usage: python compare_gen.py <repo> <ref_results> <new_results>   (needs SC4001_ROOT for CHAIR data)
"""
import json
import sys
from pathlib import Path

repo, ref, new = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
sys.path.insert(0, str(repo / "scripts"))
sys.path.insert(0, str(repo / "src"))
import numpy as np  # noqa: E402

from halluc.chair import chair_metrics  # noqa: E402
from halluc.io_utils import read_jsonl  # noqa: E402
from halluc.metrics import pope_metrics  # noqa: E402


def pope():
    for nf in sorted(new.glob("pope/*/*.jsonl")):
        rf = ref / nf.relative_to(new)
        if not rf.exists():
            print(f"[pope] {nf.relative_to(new)}: no reference file"); continue
        n = {r["question_id"]: r for r in read_jsonl(nf)}
        r = {q["question_id"]: q for q in read_jsonl(rf) if q["question_id"] in n}
        ids = sorted(n)
        same_ans = sum(n[i]["answer"] == r[i]["answer"] for i in ids)
        same_pred = sum(n[i]["pred"] == r[i]["pred"] for i in ids)
        mn, mr = pope_metrics([n[i] for i in ids]), pope_metrics([r[i] for i in ids])
        print(f"[pope] {nf.parent.name}/{nf.stem}: {len(ids)} q | identical answer {same_ans}/{len(ids)} | "
              f"identical yes/no {same_pred}/{len(ids)}")
        print(f"        ref: acc {mr['accuracy']:.4f} F1 {mr['f1']:.4f} yes {mr['yes_ratio']:.4f}   "
              f"new: acc {mn['accuracy']:.4f} F1 {mn['f1']:.4f} yes {mn['yes_ratio']:.4f}")
        flips = [i for i in ids if n[i]["pred"] != r[i]["pred"]]
        for i in flips[:5]:
            print(f"        flip q{i}: ref {r[i]['answer']!r} (p_yes {r[i].get('p_yes', float('nan')):.3f}) -> "
                  f"new {n[i]['answer']!r} (p_yes {n[i].get('p_yes', float('nan')):.3f})")
        if "p_yes" in n[ids[0]] and "p_yes" in r[ids[0]]:
            dp = np.array([n[i]["p_yes"] - r[i]["p_yes"] for i in ids])
            ds = np.array([np.subtract(n[i]["img_share_last"], r[i]["img_share_last"]) for i in ids])
            rel = np.abs(ds) / np.maximum(np.abs(np.array([r[i]["img_share_last"] for i in ids])), 1e-6)
            print(f"        p_yes |diff| mean {np.abs(dp).mean():.4f} max {np.abs(dp).max():.4f}; "
                  f"img_share_last |diff| mean {np.abs(ds).mean():.5f} (median rel {np.median(rel):.3%})")


def prefix(a, b):
    k = 0
    for x, y in zip(a, b):
        if x != y:
            break
        k += 1
    return k


def chair():
    from caption_chair import load_chair_scorer, score_records
    scorer = None
    for nf in sorted(new.glob("chair/*/*.jsonl")):
        if nf.stem.endswith("_scored"):
            continue
        rf = ref / nf.relative_to(new)
        if not rf.exists():
            print(f"[chair] {nf.relative_to(new)}: no reference file"); continue
        scorer = scorer or load_chair_scorer()
        n = {r["image"]: r for r in read_jsonl(nf)}
        r = {q["image"]: q for q in read_jsonl(rf) if q["image"] in n}
        ims = [i for i in n if i in r]
        same = sum(n[i]["caption"] == r[i]["caption"] for i in ims)
        pre = [prefix(n[i]["token_ids"], r[i]["token_ids"]) / max(len(r[i]["token_ids"]), 1) for i in ims]
        sn = score_records([n[i] for i in ims], *scorer)
        sr = score_records([r[i] for i in ims], *scorer)
        mn, mr = chair_metrics(sn), chair_metrics(sr)
        print(f"[chair] {nf.parent.name}/{nf.stem}: {len(ims)} captions | identical {same}/{len(ims)} | "
              f"mean shared prefix {np.mean(pre):.1%} of reference tokens")
        for k in ("chair_s", "chair_i", "recall", "avg_len_words"):
            print(f"        {k:<14} ref {mr[k]:.4f}  new {mn[k]:.4f}")


def attention():
    for nf in sorted(new.glob("attention/*/*.jsonl")):
        rf = ref / nf.relative_to(new)
        n = {r["image"]: r for r in read_jsonl(nf)}
        r = {q["image"]: q for q in read_jsonl(rf) if q["image"] in n}
        dp, dl, rs = [], [], []
        for im in n:
            for a, b in zip(n[im]["mentions"], r[im]["mentions"]):
                assert a["word"] == b["word"] and a["tok_index"] == b["tok_index"]
                dp.append(np.subtract(a["share_pred"], b["share_pred"]))
                rs.append(b["share_pred"])
                dl.append(a["logprob"] - b["logprob"])
        dp, rs, dl = np.array(dp), np.array(rs), np.array(dl)
        print(f"[attention] {nf.parent.name}/{nf.stem}: {len(n)} captions, {len(dp)} mentions | share_pred |diff| "
              f"mean {np.abs(dp).mean():.5f} max {np.abs(dp).max():.4f} (median rel {np.median(np.abs(dp) / np.maximum(rs, 1e-6)):.2%}) | "
              f"logprob |diff| mean {np.abs(dl).mean():.4f}")


pope()
chair()
attention()

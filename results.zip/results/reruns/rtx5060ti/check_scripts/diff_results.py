"""Diff two results trees: JSON/JSONL compared numerically (tolerance), text exactly, images by hash.

usage: python -I diff_results.py <ref_results> <new_results> [--tol 1e-9]
Only files whose bytes differ are inspected; prints a summary per differing file.
"""
import hashlib
import json
import sys
from pathlib import Path

ref, new = Path(sys.argv[1]), Path(sys.argv[2])
tol = float(sys.argv[sys.argv.index("--tol") + 1]) if "--tol" in sys.argv else 1e-9
IGNORE_KEYS = {"time", "git_commit", "python", "platform", "argv", "torch", "transformers", "gpu"}


def walk(a, b, path, out):
    if isinstance(a, dict) and isinstance(b, dict):
        for k in sorted(set(a) | set(b)):
            if k in IGNORE_KEYS:
                continue
            if k not in a or k not in b:
                out.append(f"{path}.{k}: only in {'ref' if k in a else 'new'}")
            else:
                walk(a[k], b[k], f"{path}.{k}", out)
    elif isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            out.append(f"{path}: length {len(a)} vs {len(b)}")
        for i, (x, y) in enumerate(zip(a, b)):
            walk(x, y, f"{path}[{i}]", out)
    elif isinstance(a, (int, float)) and isinstance(b, (int, float)) and not isinstance(a, bool):
        if abs(a - b) > tol * max(1.0, abs(a)):
            out.append(f"{path}: {a} vs {b}")
    elif a != b:
        out.append(f"{path}: {str(a)[:80]!r} vs {str(b)[:80]!r}")


def load(p):
    t = p.read_text(encoding="utf-8")
    if p.suffix == ".jsonl":
        return [json.loads(l) for l in t.splitlines() if l.strip()]
    return json.loads(t)


def h(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


n_same = n_diff = 0
only_ref = sorted(str(p.relative_to(ref)) for p in ref.rglob("*") if p.is_file() and not (new / p.relative_to(ref)).exists())
only_new = sorted(str(p.relative_to(new)) for p in new.rglob("*") if p.is_file() and not (ref / p.relative_to(new)).exists())
for p in sorted(ref.rglob("*")):
    q = new / p.relative_to(ref)
    if not p.is_file() or not q.exists():
        continue
    if h(p) == h(q):
        n_same += 1
        continue
    rel = p.relative_to(ref)
    if p.suffix in (".json", ".jsonl"):
        out = []
        walk(load(p), load(q), "", out)
        if not out:
            n_same += 1          # byte-different but numerically equal (or only metadata changed)
            continue
        n_diff += 1
        print(f"DIFF {rel}: {len(out)} differing values")
        for o in out[:8]:
            print("      ", o)
    elif p.suffix in (".md", ".txt"):
        a, b = p.read_text(encoding="utf-8").splitlines(), q.read_text(encoding="utf-8").splitlines()
        d = [(i + 1, x, y) for i, (x, y) in enumerate(zip(a, b)) if x != y]
        n_diff += 1
        print(f"DIFF {rel}: {len(d)} lines differ (of {len(a)} vs {len(b)})")
        for i, x, y in d[:8]:
            print(f"       L{i}\n         ref: {x[:160]}\n         new: {y[:160]}")
    else:
        n_diff += 1
        print(f"DIFF {rel}: binary differs ({p.stat().st_size} vs {q.stat().st_size} bytes)")
print(f"\n{n_same} files identical (JSON numerically, metadata ignored), {n_diff} differ")
if only_ref:
    print("only in ref:", *only_ref, sep="\n  ")
if only_new:
    print("only in new:", *only_new, sep="\n  ")

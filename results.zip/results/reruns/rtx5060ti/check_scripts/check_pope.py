"""Independent recompute of every POPE metrics file from its per-question JSONL.

Re-parses the raw answer text (own parser, not halluc.metrics), recomputes the confusion
matrix, and compares with the saved *_metrics.json. Optionally checks labels / question
sets against the original POPE question files (--pope-dir).

usage: python -I check_pope.py <results_dir> [--pope-dir DIR]
"""
import json
import re
import sys
from pathlib import Path


def read_jsonl(p):
    with open(p, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def parse(ans):
    w = re.findall(r"[a-z]+", ans.lower())
    if w and w[0] in ("yes", "no"):
        return w[0], False
    return ("no" if ("no" in w or "not" in w) else "yes"), True


def metrics(rows):
    tp = sum(r["p"] == "yes" and r["label"] == "yes" for r in rows)
    fp = sum(r["p"] == "yes" and r["label"] == "no" for r in rows)
    tn = sum(r["p"] == "no" and r["label"] == "no" for r in rows)
    fn = sum(r["p"] == "no" and r["label"] == "yes" for r in rows)
    n = len(rows)
    pr = tp / (tp + fp) if tp + fp else 0.0
    rc = tp / (tp + fn) if tp + fn else 0.0
    return dict(n=n, accuracy=(tp + tn) / n, precision=pr, recall=rc,
                f1=2 * pr * rc / (pr + rc) if pr + rc else 0.0, yes_ratio=(tp + fp) / n,
                tp=tp, fp=fp, tn=tn, fn=fn, n_parse_fallback=sum(r["fb"] for r in rows))


def main():
    res = Path(sys.argv[1])
    pope_dir = Path(sys.argv[sys.argv.index("--pope-dir") + 1]) if "--pope-dir" in sys.argv else None
    gt = {}
    if pope_dir:
        for s in ("random", "popular", "adversarial"):
            gt[s] = {r["question_id"]: r for r in read_jsonl(pope_dir / f"coco_pope_{s}.json")}
        gt["dev_random"] = {r["question_id"]: r for r in read_jsonl(pope_dir / "dev_pope_random.jsonl")}
    bad = 0
    n_files = 0
    for mfile in sorted(res.glob("pope/*/*_metrics.json")):
        split = mfile.name[:-len("_metrics.json")]
        jl = mfile.with_name(split + ".jsonl")
        saved = json.loads(mfile.read_text(encoding="utf-8"))
        rows = read_jsonl(jl)
        ids = [r["question_id"] for r in rows]
        issues = []
        if len(ids) != len(set(ids)):
            issues.append(f"duplicate question ids ({len(ids) - len(set(ids))})")
        for r in rows:
            r["p"], r["fb"] = parse(r["answer"])
            if r["p"] != r["pred"]:
                issues.append(f"q{r['question_id']}: saved pred {r['pred']} but answer {r['answer']!r} parses {r['p']}")
                break
        if split in gt:
            g = gt[split]
            if set(ids) != set(g):
                issues.append(f"question set differs from POPE file: {len(set(ids) - set(g))} extra, {len(set(g) - set(ids))} missing")
            for r in rows:
                q = g.get(r["question_id"])
                if q and (q["label"] != r["label"] or q["text"] != r["text"] or q["image"] != r["image"]):
                    issues.append(f"q{r['question_id']}: label/text/image differs from POPE file")
                    break
        mine = metrics(rows)
        for k, v in mine.items():
            sv = saved.get(k)
            if sv is None or abs(sv - v) > 1e-9:
                issues.append(f"{k}: saved {sv} recomputed {v}")
        n_files += 1
        tag = mfile.parent.name
        status = "OK " if not issues else "BAD"
        bad += bool(issues)
        if issues or tag in ("baseline", "intervention", "cautious", "pai"):
            print(f"{status} {tag}/{split}: n={mine['n']} acc={mine['accuracy']:.4f} f1={mine['f1']:.4f} "
                  f"yes={mine['yes_ratio']:.4f} fallback={mine['n_parse_fallback']}")
        for i in issues:
            print("     ", i)
    print(f"\n{n_files} POPE metric files checked, {bad} with issues")


if __name__ == "__main__":
    main()

## Table: POPE (test, 3 x 3,000 questions)

| Method | Split | Acc | Prec | Rec | F1 | Yes % | McNemar p vs baseline |
|---|---|---|---|---|---|---|---|
| Baseline | random | 88.2 | 98.1 | 77.9 | 86.8 | 39.7 | - |
| Cautious prompt | random | 88.8 | 97.4 | 79.8 | 87.7 | 41.0 | 0.00907 |
| Image-attention boost | random | 87.9 | 98.1 | 77.3 | 86.5 | 39.4 | 0.243 |
| PAI-style logit boost | random | 88.1 | 98.1 | 77.7 | 86.7 | 39.6 | 0.688 |
| Baseline | popular | 87.2 | 95.7 | 77.9 | 85.9 | 40.7 | - |
| Cautious prompt | popular | 87.6 | 94.5 | 79.8 | 86.5 | 42.2 | 0.228 |
| Image-attention boost | popular | 87.1 | 96.1 | 77.3 | 85.7 | 40.2 | 0.644 |
| PAI-style logit boost | popular | 87.2 | 96.0 | 77.7 | 85.9 | 40.5 | 1 |
| Baseline | adversarial | 85.8 | 92.5 | 77.9 | 84.5 | 42.1 | - |
| Cautious prompt | adversarial | 86.1 | 91.4 | 79.8 | 85.2 | 43.7 | 0.242 |
| Image-attention boost | adversarial | 85.6 | 92.6 | 77.3 | 84.3 | 41.7 | 0.471 |
| PAI-style logit boost | adversarial | 85.7 | 92.7 | 77.6 | 84.5 | 41.9 | 1 |

## Table: CHAIR (test, 500 COCO val2014 images, "Describe this image in detail.")

| Method | CHAIR-s | CHAIR-i | Recall | Words | Objects / caption | Truncated % |
|---|---|---|---|---|---|---|
| Baseline | 36.2 | 8.0 | 72.3 | 172.8 | 8.53 | 35.6 |
| Image-attention boost | 31.8 | 7.5 | 71.4 | 144.9 | 7.66 | 14.2 |
| PAI-style logit boost | 32.4 | 7.1 | 71.1 | 157.9 | 7.96 | 21.6 |

Paired image-level bootstrap, intervention - baseline (95% CI, percentage points): chair_s -4.4 [-8.4, -0.8]; chair_i -0.5 [-1.6, +0.5]; recall -0.9 [-2.5, +0.8]

Length-matched control (each pair of captions cut to the shorter one's word count): baseline CHAIR-s 31.0, CHAIR-i 7.2, recall 69.1; intervention CHAIR-s 31.4, CHAIR-i 7.4, recall 71.0; difference chair_s +0.4 [-3.6, +4.2]; chair_i +0.2 [-0.8, +1.2]; recall +1.9 [+0.0, +3.9]

PAI-style - baseline (paired bootstrap, 95% CI, points): chair_s -3.8 [-7.8, +0.0]; chair_i -0.9 [-1.8, +0.1]; recall -1.2 [-2.8, +0.3]. Length-matched: chair_s -0.4 [-4.2, +3.4]; chair_i -0.4 [-1.4, +0.6]; recall +0.4 [-1.0, +1.8]

## Dev sweep `sweep_pai` (100 dev captions, mode pai)

| alpha | layers | POPE F1 | CHAIR-s | CHAIR-i | Recall | Words |
|---|---|---|---|---|---|---|
| 0 | none | 91.2 | 31.0 | 7.4 | 73.8 | 173.3 |
| 0.05 | 2-27 | 90.8 | 33.0 | 7.4 | 71.8 | 170.5 |
| 0.1 | 2-27 | 90.7 | 27.0 | 6.1 | 70.1 | 145.7 |
| 0.2 | 2-27 | 90.8 | 23.0 | 4.7 | 70.4 | 95.0 |
| 0.5 | 2-27 | 89.2 | 9.0 | 5.0 | 47.5 | 23.8 |
| 0.05 | 6-13 | 91.2 | 34.0 | 8.1 | 73.8 | 174.2 |
| 0.1 | 6-13 | 91.1 | 36.0 | 7.7 | 72.4 | 172.9 |
| 0.2 | 6-13 **(selected)** | 91.2 | 31.0 | 7.0 | 73.1 | 168.8 |
| 0.5 | 6-13 | 91.2 | 22.0 | 7.0 | 51.8 | 74.7 |

## Dev sweep `sweep_n200` (200 dev captions, mode post)

| alpha | layers | POPE F1 | CHAIR-s | CHAIR-i | Recall | Words |
|---|---|---|---|---|---|---|
| 0 | none | 91.2 | 32.5 | 8.3 | 69.9 | 172.6 |
| 0.5 | 0-7 | 90.6 | 32.5 | 7.9 | 71.6 | 167.2 |
| 1 | 0-7 | 90.5 | 32.0 | 7.9 | 70.3 | 153.8 |
| 2 | 0-7 | 90.5 | 30.0 | 7.4 | 69.1 | 138.2 |
| 4 | 0-7 | 90.7 | 29.5 | 7.4 | 68.9 | 124.0 |
| 0.5 | 8-15 | 90.8 | 36.5 | 7.6 | 70.5 | 170.0 |
| 1 | 8-15 | 90.7 | 34.5 | 8.1 | 71.0 | 167.7 |
| 2 | 8-15 | 91.5 | 34.5 | 8.5 | 70.3 | 160.6 |
| 4 | 8-15 | 91.7 | 33.0 | 7.8 | 71.5 | 142.3 |
| 0.5 | 16-27 | 91.1 | 35.5 | 8.0 | 72.0 | 174.4 |
| 1 | 16-27 | 91.0 | 30.5 | 6.7 | 72.7 | 177.2 |
| 2 | 16-27 | 91.0 | 34.5 | 7.6 | 70.8 | 177.0 |
| 4 | 16-27 | 91.0 | 32.0 | 7.2 | 70.1 | 176.2 |
| 0.5 | 0-27 | 90.5 | 35.5 | 7.7 | 71.5 | 160.9 |
| 1 | 0-27 | 90.2 | 32.5 | 6.6 | 72.0 | 147.3 |
| 2 | 0-27 **(selected)** | 91.0 | 29.5 | 6.5 | 70.6 | 126.8 |
| 4 | 0-27 | 91.4 | 26.5 | 6.7 | 66.9 | 106.9 |
| 0.5 | 6-13 | 90.8 | 38.0 | 9.3 | 72.0 | 169.5 |
| 1 | 6-13 | 90.5 | 31.5 | 7.5 | 71.0 | 164.5 |
| 2 | 6-13 | 90.5 | 31.5 | 7.5 | 70.6 | 147.6 |
| 4 | 6-13 | 90.5 | 33.5 | 8.6 | 69.8 | 123.1 |

## Table: E4 sweep on the dev set (100 dev captions, dev POPE-style questions)

| alpha | layers | POPE acc | POPE F1 | Yes % | CHAIR-s | CHAIR-i | Recall | Words |
|---|---|---|---|---|---|---|---|---|
| 0 | none | 91.8 | 91.2 | 43.3 | 31.0 | 7.4 | 73.8 | 173.3 |
| 0.5 | 0-7 | 91.2 | 90.6 | 42.8 | 31.0 | 7.5 | 72.4 | 167.3 |
| 1 | 0-7 | 91.1 | 90.5 | 42.9 | 35.0 | 8.5 | 71.1 | 157.8 |
| 2 | 0-7 | 91.1 | 90.5 | 42.9 | 31.0 | 6.8 | 71.4 | 143.7 |
| 4 | 0-7 | 91.4 | 90.7 | 43.1 | 28.0 | 6.2 | 70.4 | 128.1 |
| 0.5 | 8-15 | 91.5 | 90.8 | 43.2 | 34.0 | 7.2 | 71.8 | 174.2 |
| 1 | 8-15 | 91.4 | 90.7 | 43.3 | 33.0 | 7.8 | 72.4 | 171.6 |
| 2 | 8-15 | 92.0 | 91.5 | 43.8 | 38.0 | 8.2 | 72.8 | 166.8 |
| 4 | 8-15 | 92.2 | 91.7 | 44.0 | 35.0 | 8.3 | 71.4 | 149.4 |
| 0.5 | 16-27 | 91.7 | 91.1 | 43.2 | 32.0 | 6.5 | 71.8 | 176.3 |
| 1 | 16-27 | 91.6 | 91.0 | 43.3 | 27.0 | 6.0 | 72.8 | 178.3 |
| 2 | 16-27 | 91.6 | 91.0 | 43.1 | 29.0 | 6.4 | 71.1 | 179.6 |
| 4 | 16-27 | 91.6 | 91.0 | 43.1 | 27.0 | 6.6 | 70.4 | 175.8 |
| 0.5 | 0-27 | 91.1 | 90.5 | 42.9 | 35.0 | 7.8 | 71.8 | 164.8 |
| 1 | 0-27 | 90.9 | 90.2 | 42.9 | 32.0 | 6.0 | 74.4 | 152.0 |
| 2 | 0-27 | 91.6 | 91.0 | 43.1 | 28.0 | 6.0 | 73.1 | 132.2 |
| 4 | 0-27 | 91.9 | 91.4 | 43.7 | 24.0 | 4.7 | 70.4 | 119.6 |
| 0.5 | 6-13 | 91.5 | 90.8 | 43.0 | 38.0 | 8.7 | 70.4 | 171.1 |
| 1 | 6-13 | 91.1 | 90.5 | 43.1 | 27.0 | 6.3 | 72.8 | 164.2 |
| 2 | 6-13 **(selected)** | 91.1 | 90.5 | 42.9 | 28.0 | 5.9 | 72.8 | 149.7 |
| 4 | 6-13 | 91.1 | 90.5 | 42.9 | 29.0 | 7.7 | 71.4 | 127.7 |

Selected: alpha = 2, layers 6-13 - lowest dev CHAIR-i with recall drop <= 0.02 and POPE-F1 drop <= 0.01.

## Table: E3 image attention as a hallucination signal

**dev**: 1624 object mentions in 199 captions, 134 hallucinated. Highest per-layer AUROC 0.643 (layer 0, 95% CI 0.594-0.688); lowest 0.454 (layer 14). Band 6-13.

| Detector (5-fold CV by image) | AUROC |
|---|---|
| position | 0.604 |
| logprob | 0.667 |
| attention | 0.540 |
| position+logprob | 0.700 |
| position+logprob+attention | 0.697 |
| single feature: attention_band (low=halluc) | 0.568 |
| single feature: logprob (low=halluc) | 0.674 |
| single feature: rel_position (late=halluc) | 0.628 |

**chair_test**: 4267 object mentions in 498 captions, 341 hallucinated. Highest per-layer AUROC 0.652 (layer 0, 95% CI 0.621-0.684); lowest 0.495 (layer 18). Band 6-13 (chosen on dev).

| Detector (5-fold CV by image) | AUROC |
|---|---|
| position | 0.623 |
| logprob | 0.648 |
| attention | 0.562 |
| position+logprob | 0.679 |
| position+logprob+attention | 0.677 |
| single feature: attention_band (low=halluc) | 0.566 |
| single feature: logprob (low=halluc) | 0.652 |
| single feature: rel_position (late=halluc) | 0.623 |

## Table: E5 abstention on POPE (band 20-27 chosen on dev; thresholds keep 80% of dev questions)

| Split | Acc (all) | Signal | AUROC (wrong) | Area under acc-coverage | Coverage @ dev thr | Acc @ dev thr |
|---|---|---|---|---|---|---|
| dev_random | 91.8 | image attention | 0.601 | 94.3 | 79.9 | 93.1 |
| dev_random | 91.8 | answer confidence | 0.876 | 98.4 | 79.9 | 97.4 |
| dev_random | 91.8 | random | 0.573 | 93.8 | - | - |
| random | 88.2 | image attention | 0.579 | 91.0 | 80.0 | 89.1 |
| random | 88.2 | answer confidence | 0.845 | 96.9 | 73.6 | 95.7 |
| random | 88.2 | random | 0.500 | 88.2 | - | - |
| popular | 87.2 | image attention | 0.569 | 90.0 | 78.5 | 87.9 |
| popular | 87.2 | answer confidence | 0.817 | 96.0 | 68.3 | 95.2 |
| popular | 87.2 | random | 0.488 | 86.9 | - | - |
| adversarial | 85.8 | image attention | 0.566 | 88.4 | 78.8 | 86.4 |
| adversarial | 85.8 | answer confidence | 0.793 | 94.9 | 62.8 | 94.4 |
| adversarial | 85.8 | random | 0.502 | 85.9 | - | - |

Caption filter (drop object mentions with low image attention, band 6-13, thresholds from dev):

| Mentions kept (dev quantile) | CHAIR-s | CHAIR-i | Recall |
|---|---|---|---|
| 1.0 | 36.2 | 8.0 | 72.3 |
| 0.9 | 33.4 | 7.7 | 71.5 |
| 0.8 | 31.4 | 7.5 | 70.8 |

## Table: E6 failure cases by heuristic cause

| Benchmark / kind | Causes |
|---|---|
| CHAIR introduced | co-occurrence: 44, other: 24, late in caption: 16 |
| CHAIR persistent | other: 63, co-occurrence: 47, late in caption: 13 |
| POPE-adversarial still | small object: 254, other: 98, co-occurrence: 54 |
| POPE-adversarial worse | small object: 14, other: 9, co-occurrence: 4 |
| POPE-popular still | small object: 254, other: 81, co-occurrence: 30 |
| POPE-popular worse | small object: 14, other: 8, co-occurrence: 1 |
| POPE-random still | small object: 254, other: 82, co-occurrence: 5 |
| POPE-random worse | small object: 14, other: 8 |

## E6 hand check of CHAIR hallucination labels

Random sample (random.seed(0); random.sample of the 341 CHAIR-hallucinated mentions in results/chair/baseline/chair_test_scored.jsonl, in file order) of 30 mentions, labelled by reading the caption context only (not the image). Labels were proposed by Claude and must be checked by the team.

scoring artefact: 18; possible real hallucination (or missing annotation): 12

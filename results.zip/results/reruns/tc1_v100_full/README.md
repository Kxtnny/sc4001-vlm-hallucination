# Full rerun on the CCDS TC1 cluster (Tesla V100, float32), 2026-11-13

The whole pipeline (`sbatch tc1/run_all.sbatch` = `scripts/run_all.sh`, E0-E6, including the dev sweep
and the selection rule applied again) from the committed code at `cda1010`: Tesla V100-PCIE-32GB, float32
(the V100 has no native bfloat16), torch 2.11.0+cu126, transformers 5.22.2, SLURM job 73815,
2026-11-13 21:36 to 2026-11-14 02:27 (4 h 50 min).
**It was made after the original test runs and nothing was chosen from it.**
These files support Section 4.6 and Table 5 of the report, the rerun sentences in Sections 4.5, 5.1-5.3 and 6,
and the RUN_LOG rows for job 73815 and for the two follow-up analyses dated 2026-11-15.

Do not mix these files into the main `results/` folders: they come from different hardware and precision.

## What is here

Same layout as `results/`: `sanity/`, `pope/`, `chair/`, `attention/`, `sweep/`, `analysis/`, `figures/`, `report/`.

| Item | Contents |
|---|---|
| `pope/baseline`, `pope/cautious`, `pope/intervention` | 3 x 3,000 POPE questions each; `intervention` is the setting this rerun selected (alpha 2, layers 0-27) |
| `chair/baseline`, `chair/intervention` | 500 test captions each, scored |
| `pope/sweep_*`, `chair/sweep_*`, `sweep/` | the dev sweep (20 settings) and the selected setting |
| `attention/`, `analysis/attention_*.json`, `analysis/e3_layer_choice.json` | E3 |
| `analysis/abstention.json`, `analysis/failure_cases.*` | E5 and E6 |
| `analysis/abstention_combined.json` | follow-up: confidence + layer-20 attention for abstention (`scripts/abstention_combined.py`) |
| `analysis/recall_by_size.json` | follow-up: POPE recall by object size (`scripts/resolution_analysis.py --control baseline --tags intervention --out-name recall_by_size`) |
| `report/tables.md`, `report/numbers.json` | built from these outputs with `scripts/make_report.py` |
| `run_all_73815.out`, `run_all_73815.err` | the job logs |

The job stopped with an error in its last step only (`make_report.py`, the qualitative-example assertion,
fixed in commit `f7ebba3`); every experiment had finished. Not run here: `scripts/run_extra.sh`
(the PAI-style comparison and the 200-caption sweep).

## Main findings

- POPE and the analyses reproduce: accuracy 88.4 / 87.5 / 86.1 (original 88.2 / 87.2 / 85.8); E3 again finds
  layer 0 best (AUROC 0.658) and band 6-13 on dev; E5 gives the same ranking, band 20-27 and the reversed layer-20 signal.
- The CHAIR effects do not: the rule selects alpha 2 on layers 0-27 instead of 6-13, and the CHAIR-s drop is not
  significant (35.0 -> 32.4, -2.6 [-6.8, +1.6]); CHAIR-i -0.7 [-1.8, +0.4], length-matched -0.2 [-1.4, +0.8].
- With that setting the boost lowers random-split POPE accuracy by 0.4 points (McNemar p = 0.041, uncorrected).
- The cautious prompt's gain is not reproduced (+0.2 / -0.1 / -0.2 points, p >= 0.29).

# Second-GPU reproducibility check (RTX 5060 Ti), 2026-11-12

A check of the original results (RTX 4060 Laptop) on a different GPU. Same software
(torch 2.11.0+cu128, transformers 5.22.2, bfloat16), code at commit `cda1010`.
**Nothing here was used to choose anything, and no test set was re-run with a new setting.**
These files support the RUN_LOG rows dated 2026-11-12 and the report text on reproducibility
(Sections 3.2, 4.4, 5.3, 5.4, Appendix A).

Do not mix these files into the main `results/` folders: they come from different hardware.

## What is here

| Folder | Contents |
|---|---|
| `sanity/` | E0 on this GPU, in bfloat16 and in float32 |
| `pope/baseline/` | dev questions (902, with signals) and POPE random (3,000, with signals), unmodified model |
| `pope/intervention/` | POPE random (3,000) with the frozen boost (alpha 2, layers 6-13) |
| `pope/sweep_*/` | dev questions for each of the 20 sweep settings |
| `chair/baseline/` | first 48 test captions (`chair_test.jsonl`) and the 100-caption dev sweep subset (`dev.jsonl`, `dev_n100_*`) |
| `chair/intervention/` | first 48 test captions with the frozen boost |
| `chair/sweep_*/` | 100 dev captions for each sweep setting |
| `sweep/`, `figures/e4_sweep_dev.png` | the full dev sweep table and the setting it would select on this GPU |
| `attention/baseline/` | E3 attention, teacher-forced on 40 of the ORIGINAL saved test captions |
| `comparison/` | text outputs of every comparison with the original results (the numbers in RUN_LOG come from these) |
| `check_scripts/` | the scripts that made the comparisons, and `spot_captions.py` (first 48 test captions in the original batches of 8) |

The first 48 test captions are only a subset, so `chair/*/chair_test.jsonl` has no metrics file. Compare them
per caption, as `comparison/generation_vs_original.txt` does.

## Main findings

- Scoring and analysis: every metric, table and figure rebuilds identically from the saved outputs
  (`comparison/analysis_rerun_vs_original.txt`, `comparison/pope_metrics_recomputed.txt`).
- POPE reproduces: 99.4-99.8% identical yes/no answers, and the flips are close calls (p_yes about 0.5). Random: acc 88.17 -> 88.60
  (baseline), 87.90 -> 88.30 (boost), so boost vs baseline is about -0.3 points on both GPUs.
- E0 passes in bf16 and fp32. E3 attention matches to about 1% relative.
- Captions do not reproduce word for word (0-8% identical). This is bf16 rounding drift between GPU architectures:
  the drift is about as large as the bf16-vs-fp32 gap on a single GPU (`comparison/e0_bf16_vs_fp32.txt`).
  CHAIR on 100 captions moves by up to about 2 points.
- Dev sweep on this GPU would select alpha 4, layers 16-27. The frozen choice (alpha 2, layers 6-13) ranks
  19th of 21 here and fails the selection criteria. Spearman correlation across settings is 0.54 for CHAIR-i
  and 0.98 for caption length (`comparison/sweep_vs_original.txt`).

# E6 failure cases (auto-grouped; check each by hand)

Intervention tag: `intervention`. Counts by benchmark/kind and heuristic cause:

- **CHAIR introduced**: co-occurrence 44, other 24, late in caption 16
- **CHAIR persistent**: other 63, co-occurrence 47, late in caption 13
- **POPE-adversarial still**: small object 254, other 98, co-occurrence 54
- **POPE-adversarial worse**: small object 14, other 9, co-occurrence 4
- **POPE-popular still**: small object 254, other 81, co-occurrence 30
- **POPE-popular worse**: small object 14, other 8, co-occurrence 1
- **POPE-random still**: small object 254, other 82, co-occurrence 5
- **POPE-random worse**: small object 14, other 8

## Sampled cases

### 1. POPE-random - worse - `couch` (other)
Image `COCO_val2014_000000246999.jpg`; ground-truth objects: chair, clock, couch, potted plant, remote, tv, vase
- label yes; baseline said 'Yes', intervention said 'no'

### 2. POPE-popular - worse - `person` (small object)
Image `COCO_val2014_000000354229.jpg`; ground-truth objects: bus, car, person
- label yes; baseline said 'yes', intervention said 'no'

### 3. CHAIR - introduced - `bear` (late in caption)
Image `COCO_val2014_000000056874.jpg`; ground-truth objects: donut, person
- baseline: The image depicts a group of people dressed in various costumes, likely participating in a themed party or costume event. The setting appears to be indoors, possibly in a barn or a similar rustic environment, as suggested by the hay bales and the rustic decor in the background. 

1. **Foreground:**
   - **Person in a Chef's Hat:** The person in the foreground is wearing a chef's hat, which is white and has a chef's jacket over it. The person is standing with one hand on their hip and appears to be smiling or laughing.
   - **Person in a Sesame Street Character Costume:** The person in the middle is dressed as Elmo, a character from the children's television show "Sesame Street." Elmo is wearing a blue costume with a red hat and a white shirt. He is standing next to a person in a green and yellow striped costume, which is likely a character from the show.
   - **Person in a Hay Bale Costume:** The person in the background is wearing a costume that resembles a large, round hay bale. The bale is brown and has a hole in the center, which is typical of a hay bale.

2. **Background:**
   - **Lighting:** The background is
- intervention: The image depicts a group of people dressed in various costumes, likely participating in a themed event or party. The setting appears to be indoors, possibly in a barn or a similar rustic environment, as indicated by the hay bales and the rustic wooden structure in the background. 

In the foreground, there is a person dressed in a chef's costume, standing with one hand on their hip. This person is wearing a white chef's coat, beige pants, and a white hat. The chef's hat is adorned with a decorative bow. The person is also holding a glass of wine, suggesting a social gathering or celebration.

To the left of the chef, there is another individual dressed in a costume that resembles a Sesame Street character, specifically Elmo. Elmo is wearing a blue costume with a red hat and is holding a drink in his hand. The costume includes a blue hat and a blue shirt with a red and yellow pattern.

In the background, there is another person dressed in a costume that appears to be a bear or a similar animal, wearing a red hat and a red outfit. This person is also holding a drink in their hand.

The overall atmosphere of the image suggests a fun and festive environment, with the group enjoying each other's company and participating in a

### 4. CHAIR - introduced - `toaster` (late in caption)
Image `COCO_val2014_000000437789.jpg`; ground-truth objects: apple, bowl, broccoli, carrot, cup, dining table, microwave, orange
- baseline: The image depicts a well-organized meal setup on a countertop. The meal appears to be a balanced and nutritious snack or lunch, featuring a variety of fresh fruits, vegetables, and a small portion of rice. Here is a detailed description of the items present in the image:

1. **Apples**: There are two apples placed on the countertop. One apple is a red apple, and the other appears to be a yellow apple, possibly an orange or a similar fruit. Both apples are whole and appear to be fresh.

2. **Orange**: There is an orange placed next to the apples. The orange is bright orange in color and looks fresh, with a smooth and vibrant texture.

3. **Tomatoes**: There are several small, red tomatoes placed in a clear plastic container. The tomatoes are in a small bunch, and they appear to be fresh and ripe.

4. **Carrots**: There are several carrot sticks placed in a plastic container. The carrots are orange in color and appear to be fresh.

5. **Broccoli**: There is a small piece of broccoli placed in a plastic container. The broccoli is green and looks fresh, with a slightly crunchy texture.

6. **Cucumbers**: There are several small cucumbers placed in
- intervention: The image depicts a well-organized meal setup on a countertop. The meal consists of various food items neatly arranged in clear plastic containers and containers. 

Starting from the left, there is a container filled with a variety of vegetables, including carrots, broccoli, and possibly some other vegetables. Next to this container is an apple, adding a touch of fruit to the meal. 

In the center of the image, there is a container filled with tomatoes, which are a common ingredient in many meals. To the right of the tomatoes, there is a container filled with grapes, adding a pop of color and a sweet flavor to the meal.

On the right side of the image, there is a container filled with rice, which is a staple food item in many cuisines. Next to the rice container, there is a container filled with a white substance, possibly a type of cereal or a grain-based food.

In the background, there is a microwave and a toaster, indicating that this meal is likely part of a larger meal preparation process. The overall setup suggests a balanced and nutritious meal, combining different food groups and flavors.

### 5. POPE-adversarial - worse - `chair` (small object)
Image `COCO_val2014_000000424792.jpg`; ground-truth objects: cat, vase
- label yes; baseline said 'yes', intervention said 'no'

### 6. POPE-popular - worse - `bowl` (small object)
Image `COCO_val2014_000000117527.jpg`; ground-truth objects: bowl, cup, dining table, person
- label yes; baseline said 'yes', intervention said 'no'

### 7. POPE-random - worse - `orange` (small object)
Image `COCO_val2014_000000191964.jpg`; ground-truth objects: cat, keyboard
- label yes; baseline said 'yes', intervention said 'no'

### 8. CHAIR - introduced - `person` (co-occurrence)
Image `COCO_val2014_000000535579.jpg`; ground-truth objects: bear, book, suitcase, teddy bear, tie
- baseline: The image depicts a display of two teddy bears sitting on top of a wooden chest. The teddy bears are beige in color and appear to be stuffed animals. They are positioned facing each other, with their arms around each other, creating a sense of affection or companionship. The teddy bears are adorned with tags, one of which is green and the other is yellow, possibly indicating they are new or have been recently purchased.

The chest they are sitting on is open, revealing a glimpse of the inside. Inside the chest, there are several items. The most noticeable item is a book titled "ADVENTURE," which is placed on the chest. The book has a cover that appears to be a cityscape, suggesting it might be a travel or adventure-themed book. The book is placed on top of a stack of smaller boxes, which are also beige and have a plaid pattern. These boxes are stacked in a way that they form a small shelf or platform.

The background of the image shows a portion of a window display, which includes other items. There is a red ribbon tied around a box, and another box with a red and gold ribbon, possibly indicating a gift or a special occasion. The overall setting suggests a festive or holiday atmosphere, possibly related to
- intervention: The image depicts a display of two teddy bears sitting on top of a wooden chest. The teddy bears are beige in color and appear to be stuffed animals. They are adorned with tags and ribbons, suggesting they are new or recently purchased. The teddy bears are positioned facing each other, with one slightly behind the other, creating a sense of companionship.

In front of the teddy bears, there is a book titled "ADVENTURE," which is open to the first page. The book cover features a picture of a building, indicating it might be a children's book. The book is placed on a small stack of books or boxes, which are also beige and match the color of the teddy bears.

To the right of the teddy bears, there is a red box with a bow, adding a festive touch to the display. The box appears to be a gift or a decorative item, possibly for a child or a collector.

In the background, there is a large wooden chest with a lid that is open, revealing more items inside. The chest has a gold-colored handle and a handle on the lid. The interior of the chest is not fully visible, but it seems to contain more toys or decorative items.

The overall setting suggests a festive or

### 9. POPE-adversarial - still - `spoon` (small object)
Image `COCO_val2014_000000134075.jpg`; ground-truth objects: bottle, cell phone, cup, dining table, person, spoon
- label yes; baseline said 'no', intervention said 'no'

### 10. POPE-popular - still - `bottle` (small object)
Image `COCO_val2014_000000167724.jpg`; ground-truth objects: bottle, person, spoon
- label yes; baseline said 'no', intervention said 'no'

### 11. POPE-adversarial - still - `truck` (small object)
Image `COCO_val2014_000000505933.jpg`; ground-truth objects: car, train, truck
- label yes; baseline said 'no', intervention said 'no'

### 12. POPE-random - still - `chair` (small object)
Image `COCO_val2014_000000355776.jpg`; ground-truth objects: cup, person, sink, toothbrush
- label yes; baseline said 'no', intervention said 'no'

### 13. POPE-adversarial - still - `backpack` (co-occurrence)
Image `COCO_val2014_000000200583.jpg`; ground-truth objects: bottle, suitcase
- label no; baseline said 'yes', intervention said 'yes'

### 14. POPE-random - still - `tv` (other)
Image `COCO_val2014_000000287035.jpg`; ground-truth objects: cell phone, chair, keyboard, laptop, mouse, tv
- label yes; baseline said 'no', intervention said 'no'

### 15. POPE-popular - still - `chair` (co-occurrence)
Image `COCO_val2014_000000358255.jpg`; ground-truth objects: bed, book, teddy bear
- label no; baseline said 'yes', intervention said 'yes'

### 16. POPE-random - still - `person` (other)
Image `COCO_val2014_000000299074.jpg`; ground-truth objects: bus, cell phone, person
- label yes; baseline said 'no', intervention said 'no'

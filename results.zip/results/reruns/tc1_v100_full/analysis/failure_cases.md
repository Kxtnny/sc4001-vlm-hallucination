# E6 failure cases (auto-grouped; check each by hand)

Intervention tag: `intervention`. Counts by benchmark/kind and heuristic cause:

- **CHAIR introduced**: co-occurrence 48, other 30, late in caption 23
- **CHAIR persistent**: other 56, co-occurrence 43, late in caption 10
- **POPE-adversarial still**: small object 249, other 99, co-occurrence 54
- **POPE-adversarial worse**: small object 21, other 4, co-occurrence 3
- **POPE-popular still**: small object 249, other 79, co-occurrence 29
- **POPE-popular worse**: small object 21, co-occurrence 3, other 1
- **POPE-random still**: small object 249, other 83, co-occurrence 4
- **POPE-random worse**: small object 21, other 3

## Sampled cases

### 1. CHAIR - introduced - `truck` (co-occurrence)
Image `COCO_val2014_000000573947.jpg`; ground-truth objects: bicycle, car, person, traffic light
- baseline: The image depicts a street scene with several notable elements. In the foreground, there is a white van parked on the side of the road. The van is partially visible, with its rear end and part of its side window showing. The van appears to be stationary, possibly waiting for traffic to clear or for pedestrians to cross.

Above the van, there are two traffic lights mounted on a pole. The traffic lights are displaying a green signal, indicating that vehicles can proceed. The green light is illuminated, and the numbers "70" are visible on the traffic lights, suggesting that the signal is for vehicles to proceed at a speed of 70 kilometers per hour.

In the background, there is a bridge or overpass that spans across the scene. The bridge has a metallic railing on its side, and it appears to be made of steel or a similar material. The bridge is partially visible, with the top of the bridge and the railing clearly visible.

Further back, there are some buildings and trees lining the street. The buildings are not clearly identifiable, but they appear to be of a moderate height. The trees are tall and have a mix of green and brown foliage, indicating that it might be either early spring or late autumn.

Additionally, there are some flags or banners
- intervention: The image depicts a traffic scene with a white van and a traffic light in the foreground. The traffic light is displaying a green signal, indicating that vehicles can proceed. The van is positioned on the left side of the image, and it appears to be moving or stationary. 

In the background, there are several other vehicles, including a car and a truck, which are also visible. The scene is set in an urban area with a bridge and a building visible in the distance. The sky is overcast, and the overall atmosphere appears to be cloudy and hazy.

### 2. POPE-random - worse - `chair` (other)
Image `COCO_val2014_000000113701.jpg`; ground-truth objects: bed, book, chair, clock
- label yes; baseline said 'yes', intervention said 'no'

### 3. CHAIR - introduced - `person` (co-occurrence)
Image `COCO_val2014_000000062661.jpg`; ground-truth objects: car, fire hydrant
- baseline: The image depicts a scene on a city street. The primary focus is on a red fire hydrant, which is positioned on the sidewalk. The fire hydrant has a cylindrical shape with a metallic red body and a brownish-red top. It appears to be old and weathered, with some rust and discoloration visible. The hydrant is connected to a hose, which is visible at the top of the hydrant.

In the background, there is a yellow taxi cab. The taxi is painted in a bright orange color and has the word "NYC" written on it in black letters. The word "TAXI" is also visible, indicating that this is a taxi. The taxi has a black and white logo on the side, which is not clearly visible in the image. The taxi's license plate is partially visible, showing a combination of numbers and letters.

The street surface is paved with asphalt, and there is a small puddle of water near the fire hydrant, suggesting recent rain or a wet sidewalk. The sidewalk is made of concrete and appears to be clean and well-maintained.

The overall scene suggests a typical urban environment, with the fire hydrant and taxi being common elements in such settings. The presence of the taxi indicates that this
- intervention: The image depicts a scene in New York City, featuring a red fire hydrant on the sidewalk next to an orange taxi. The fire hydrant is positioned on the left side of the image, with its red and brown paint peeling off, revealing the underlying metal. The hydrant is connected to a hose, which is visible in the image.

The taxi is parked on the street, with its orange color and the "NYC TAXI" logo clearly visible on the side. The taxi's door is open, and the driver is not visible in the image. The overall scene suggests a typical urban setting in New York City, with the fire hydrant and taxi being iconic symbols of the city's infrastructure and transportation system.

### 4. CHAIR - introduced - `bed` (late in caption)
Image `COCO_val2014_000000346138.jpg`; ground-truth objects: bowl, broccoli, cup, dining table, pizza, spoon
- baseline: The image is a collage of five different dishes, each representing a different type of Japanese cuisine. Here is a detailed description of each dish:

1. **Top Left**: This dish features a bowl of rice topped with a variety of ingredients. The rice appears to be cooked with a green leafy vegetable, possibly spinach or a similar leaf. There is also a piece of meat, possibly pork or chicken, and a small piece of tofu or another type of protein. The dish is garnished with a green leaf, likely spinach, and a small piece of green onion or cilantro.

2. **Top Right**: This dish consists of a bowl of noodles, likely soba or udon, served in a clear broth. The noodles are thin and have a light brown color, indicating they are cooked in a light broth. The broth is clear and has a slight brownish tint, suggesting it might be soy-based. The dish is garnished with a small piece of meat, possibly pork or chicken, and a small piece of tofu or another type of protein.

3. **Middle Left**: This dish features a bowl of rice topped with a variety of ingredients. The rice appears to be cooked with a green leafy vegetable, possibly spinach or a similar leaf. There is also
- intervention: The image is a collage of five different dishes, each representing a different type of Japanese cuisine. Here is a detailed description of each dish:

1. **Top Left**: A bowl of rice topped with a variety of ingredients, including a green leafy vegetable, a piece of meat, and a fried egg. The rice appears to be seasoned with a light sauce, and the dish is presented on a wooden table.

2. **Top Right**: A bowl of noodles with a clear broth, likely a type of ramen. The noodles are thin and have a light brown color, and the broth is clear with a slight hint of umami.

3. **Middle Left**: A dish featuring a piece of grilled meat, possibly pork, served with a side of rice and a green leafy vegetable. The meat appears to be well-cooked and has a crispy exterior.

4. **Middle Right**: A bowl of soup, likely miso soup, with a dark broth and a piece of meat. The soup is garnished with a green leafy vegetable and a piece of tofu. The dish is served on a wooden table.

5. **Bottom Left**: A dish consisting of a bed of rice topped with a variety of ingredients, including a piece of meat, a piece of

### 5. POPE-popular - worse - `baseball glove` (small object)
Image `COCO_val2014_000000083275.jpg`; ground-truth objects: baseball bat, baseball glove, person
- label yes; baseline said 'yes', intervention said 'no'

### 6. POPE-random - worse - `sports ball` (small object)
Image `COCO_val2014_000000555538.jpg`; ground-truth objects: baseball bat, baseball glove, person
- label yes; baseline said 'yes', intervention said 'no'

### 7. POPE-random - worse - `chair` (small object)
Image `COCO_val2014_000000424792.jpg`; ground-truth objects: cat, vase
- label yes; baseline said 'yes', intervention said 'no'

### 8. CHAIR - introduced - `cell phone` (late in caption)
Image `COCO_val2014_000000426241.jpg`; ground-truth objects: dining table, keyboard, laptop, mouse, person, tv
- baseline: The image depicts a small, cluttered office or home workspace. The primary focus is a glass-topped desk with a metal frame. On the desk, there are several electronic devices and cables. 

Starting from the left side of the desk, there is a white keyboard and a black mouse. Next to the keyboard, there is a black printer. In front of the printer, there is a black laptop computer. To the right of the laptop, there is a black computer monitor displaying a video. 

The desk is also equipped with a black keyboard and a white mouse. Additionally, there are several cords and cables scattered across the desk, indicating a high level of connectivity and possibly a need for multiple devices. 

The background of the image shows a white wall with a closed door, and a small window with blinds. The overall scene suggests a busy and functional workspace, with various electronic devices and cables indicating a high level of connectivity and possibly a need for multiple devices.
- intervention: The image depicts a small, cluttered office or home office setup. The room has a glass desk with a computer monitor, keyboard, and mouse on it. The desk is surrounded by various electronic devices and cables, indicating a busy workspace. 

There are two keyboards visible on the desk, one on the left side and another on the right side. A printer is also present on the left side of the desk. The desk is situated in a corner of the room, with a door visible in the background. 

Additionally, there is a cup and a cell phone on the desk, along with a few other miscellaneous items. The overall scene suggests a busy and functional workspace, with a mix of technology and personal items.

### 9. POPE-adversarial - still - `truck` (other)
Image `COCO_val2014_000000377879.jpg`; ground-truth objects: train, truck
- label yes; baseline said 'no', intervention said 'no'

### 10. POPE-popular - still - `tv` (other)
Image `COCO_val2014_000000068418.jpg`; ground-truth objects: keyboard, mouse, tv
- label yes; baseline said 'no', intervention said 'no'

### 11. POPE-adversarial - still - `spoon` (co-occurrence)
Image `COCO_val2014_000000190788.jpg`; ground-truth objects: cup, knife, person, pizza
- label no; baseline said 'yes', intervention said 'yes'

### 12. POPE-popular - still - `potted plant` (small object)
Image `COCO_val2014_000000211674.jpg`; ground-truth objects: bus, car, person, potted plant
- label yes; baseline said 'no', intervention said 'no'

### 13. POPE-adversarial - still - `snowboard` (small object)
Image `COCO_val2014_000000214244.jpg`; ground-truth objects: person, skis, snowboard
- label yes; baseline said 'no', intervention said 'no'

### 14. POPE-random - still - `bench` (small object)
Image `COCO_val2014_000000200583.jpg`; ground-truth objects: bottle, suitcase
- label yes; baseline said 'no', intervention said 'no'

### 15. POPE-popular - still - `sports ball` (small object)
Image `COCO_val2014_000000124629.jpg`; ground-truth objects: person, sports ball, tennis racket
- label yes; baseline said 'no', intervention said 'no'

### 16. POPE-random - still - `person` (small object)
Image `COCO_val2014_000000017379.jpg`; ground-truth objects: person, sink, tv
- label yes; baseline said 'no', intervention said 'no'

"""Side-by-side comparison of two E4 dev sweep tables (original vs rerun on another GPU).

usage: python -I compare_sweep.py <ref_results> <new_results>
"""
import json
import sys
from pathlib import Path

ref, new = Path(sys.argv[1]), Path(sys.argv[2])
R = {r["tag"]: r for r in json.loads((ref / "sweep/sweep_table.json").read_text())["rows"]}
N = {r["tag"]: r for r in json.loads((new / "sweep/sweep_table.json").read_text())["rows"]}
rs, ns = (json.loads((p / "sweep/selected.json").read_text()) for p in (ref, new))
tags = [t for t in R if t in N]


def rank(vals):
    order = sorted(range(len(vals)), key=lambda i: vals[i])
    r = [0] * len(vals)
    for k, i in enumerate(order):
        r[i] = k
    return r


def spearman(a, b):
    ra, rb = rank(a), rank(b)
    n = len(a)
    return 1 - 6 * sum((x - y) ** 2 for x, y in zip(ra, rb)) / (n * (n * n - 1))


def ok(r, base):  # the selection constraints from scripts/sweep.py
    return (r["alpha"] != 0 and r["recall"] >= base["recall"] - 0.02 and r["pope_f1"] >= base["pope_f1"] - 0.01
            and r["chair_i"] < base["chair_i"])


bR, bN = R["baseline"], N["baseline"]
print(f"{'setting':<18}{'CHAIR-i ref':>12}{'new':>7}{'diff':>7} | {'recall ref':>10}{'new':>7} | {'F1 ref':>7}{'new':>7} | "
      f"{'words ref':>9}{'new':>6} | ok ref/new")
for t in sorted(tags, key=lambda t: R[t]["chair_i"]):
    a, b = R[t], N[t]
    print(f"{t:<18}{a['chair_i']:>12.4f}{b['chair_i']:>7.4f}{b['chair_i'] - a['chair_i']:>+7.4f} | {a['recall']:>10.3f}"
          f"{b['recall']:>7.3f} | {a['pope_f1']:>7.4f}{b['pope_f1']:>7.4f} | {a['avg_len_words']:>9.1f}"
          f"{b['avg_len_words']:>6.1f} | {'Y' if ok(a, bR) else '-'}/{'Y' if ok(b, bN) else '-'}")
for k in ("chair_i", "chair_s", "recall", "pope_f1", "avg_len_words"):
    a, b = [R[t][k] for t in tags], [N[t][k] for t in tags]
    mad = sum(abs(x - y) for x, y in zip(a, b)) / len(a)
    print(f"{k:<14} Spearman(ref, new) = {spearman(a, b):+.2f}   mean |diff| = {mad:.4f}")
print(f"\nsettings meeting the constraints: ref {sum(ok(R[t], bR) for t in tags)}, new {sum(ok(N[t], bN) for t in tags)}, "
      f"both {sum(ok(R[t], bR) and ok(N[t], bN) for t in tags)}")
print("selected ref:", rs["tag"], rs["dev"], "met" if rs["constraints_met"] else "NOT met")
print("selected new:", ns["tag"], ns["dev"], "met" if ns["constraints_met"] else "NOT met")
print(f"new GPU: rank of the original pick ({rs['tag']}) by CHAIR-i: "
      f"{sorted(tags, key=lambda t: N[t]['chair_i']).index(rs['tag']) + 1} of {len(tags)}")

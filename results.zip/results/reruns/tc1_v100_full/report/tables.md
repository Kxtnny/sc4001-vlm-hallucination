## Table: POPE (test, 3 x 3,000 questions)

| Method | Split | Acc | Prec | Rec | F1 | Yes % | McNemar p vs baseline |
|---|---|---|---|---|---|---|---|
| Baseline | random | 88.4 | 98.2 | 78.3 | 87.1 | 39.9 | - |
| Cautious prompt | random | 88.7 | 98.0 | 78.9 | 87.4 | 40.3 | 0.296 |
| Image-attention boost | random | 88.0 | 98.1 | 77.5 | 86.6 | 39.5 | 0.041 |
| Baseline | popular | 87.5 | 95.9 | 78.3 | 86.2 | 40.8 | - |
| Cautious prompt | popular | 87.4 | 94.9 | 78.9 | 86.2 | 41.6 | 0.652 |
| Image-attention boost | popular | 87.3 | 96.4 | 77.5 | 85.9 | 40.2 | 0.36 |
| Baseline | adversarial | 86.1 | 92.7 | 78.3 | 84.9 | 42.3 | - |
| Cautious prompt | adversarial | 85.8 | 91.6 | 78.9 | 84.8 | 43.1 | 0.382 |
| Image-attention boost | adversarial | 85.7 | 92.7 | 77.5 | 84.4 | 41.8 | 0.0961 |

## Table: CHAIR (test, 500 COCO val2014 images, "Describe this image in detail.")

| Method | CHAIR-s | CHAIR-i | Recall | Words | Objects / caption | Truncated % |
|---|---|---|---|---|---|---|
| Baseline | 35.0 | 7.8 | 71.3 | 184.4 | 8.78 | 45.0 |
| Image-attention boost | 32.4 | 7.1 | 73.3 | 145.7 | 8.07 | 12.4 |

Paired image-level bootstrap, intervention - baseline (95% CI, percentage points): chair_s -2.6 [-6.8, +1.6]; chair_i -0.7 [-1.8, +0.4]; recall +2.0 [+0.1, +3.9]

Length-matched control (each pair of captions cut to the shorter one's word count): baseline CHAIR-s 29.0, CHAIR-i 7.3, recall 66.6; intervention CHAIR-s 31.8, CHAIR-i 7.1, recall 73.1; difference chair_s +2.8 [-1.4, +7.0]; chair_i -0.2 [-1.4, +0.8]; recall +6.5 [+4.3, +8.6]

## Table: E4 sweep on the dev set (100 dev captions, dev POPE-style questions)

| alpha | layers | POPE acc | POPE F1 | Yes % | CHAIR-s | CHAIR-i | Recall | Words |
|---|---|---|---|---|---|---|---|---|
| 0 | none | 91.5 | 90.8 | 42.8 | 36.0 | 6.9 | 73.4 | 189.5 |
| 0.5 | 0-7 | 91.0 | 90.3 | 42.4 | 40.0 | 7.6 | 74.1 | 184.5 |
| 1 | 0-7 | 91.0 | 90.3 | 42.4 | 33.0 | 6.0 | 74.4 | 175.9 |
| 2 | 0-7 | 91.5 | 90.8 | 42.8 | 36.0 | 7.4 | 72.4 | 161.3 |
| 4 | 0-7 | 91.5 | 90.8 | 43.0 | 35.0 | 7.7 | 68.8 | 144.9 |
| 0.5 | 8-15 | 91.5 | 90.8 | 42.8 | 35.0 | 8.0 | 73.1 | 190.3 |
| 1 | 8-15 | 91.7 | 91.1 | 43.0 | 33.0 | 6.3 | 74.4 | 189.2 |
| 2 | 8-15 | 91.6 | 91.0 | 43.1 | 35.0 | 6.1 | 74.8 | 185.6 |
| 4 | 8-15 | 91.8 | 91.3 | 43.8 | 35.0 | 8.0 | 73.8 | 170.4 |
| 0.5 | 16-27 | 91.4 | 90.7 | 42.7 | 33.0 | 5.6 | 71.8 | 187.4 |
| 1 | 16-27 | 91.4 | 90.7 | 42.7 | 33.0 | 6.5 | 72.8 | 193.0 |
| 2 | 16-27 | 91.4 | 90.7 | 42.7 | 34.0 | 6.7 | 72.8 | 192.5 |
| 4 | 16-27 | 91.4 | 90.7 | 42.7 | 34.0 | 7.1 | 71.4 | 192.3 |
| 0.5 | 0-27 | 91.6 | 90.9 | 42.7 | 33.0 | 6.3 | 72.4 | 184.1 |
| 1 | 0-27 | 91.5 | 90.8 | 42.8 | 35.0 | 7.7 | 77.4 | 171.4 |
| 2 | 0-27 **(selected)** | 91.5 | 90.8 | 42.8 | 28.0 | 5.3 | 73.4 | 151.7 |
| 4 | 0-27 | 91.7 | 91.0 | 42.8 | 28.0 | 6.7 | 73.1 | 132.9 |
| 0.5 | 6-13 | 91.2 | 90.5 | 42.6 | 31.0 | 5.5 | 74.4 | 184.7 |
| 1 | 6-13 | 91.1 | 90.4 | 42.7 | 30.0 | 5.4 | 74.4 | 176.7 |
| 2 | 6-13 | 91.4 | 90.7 | 42.7 | 31.0 | 8.1 | 72.8 | 168.5 |
| 4 | 6-13 | 91.2 | 90.6 | 42.8 | 31.0 | 7.4 | 70.8 | 137.1 |

Selected: alpha = 2, layers 0-27 - lowest dev CHAIR-i with recall drop <= 0.02 and POPE-F1 drop <= 0.01.

## Table: E3 image attention as a hallucination signal

**dev**: 1744 object mentions in 199 captions, 150 hallucinated. Highest per-layer AUROC 0.647 (layer 0, 95% CI 0.602-0.694); lowest 0.494 (layer 18). Band 6-13.

| Detector (5-fold CV by image) | AUROC |
|---|---|
| position | 0.635 |
| logprob | 0.664 |
| attention | 0.581 |
| position+logprob | 0.715 |
| position+logprob+attention | 0.712 |
| single feature: attention_band (low=halluc) | 0.593 |
| single feature: logprob (low=halluc) | 0.670 |
| single feature: rel_position (late=halluc) | 0.643 |

**chair_test**: 4392 object mentions in 497 captions, 342 hallucinated. Highest per-layer AUROC 0.658 (layer 0, 95% CI 0.624-0.694); lowest 0.473 (layer 18). Band 6-13 (chosen on dev).

| Detector (5-fold CV by image) | AUROC |
|---|---|
| position | 0.601 |
| logprob | 0.632 |
| attention | 0.535 |
| position+logprob | 0.666 |
| position+logprob+attention | 0.662 |
| single feature: attention_band (low=halluc) | 0.554 |
| single feature: logprob (low=halluc) | 0.640 |
| single feature: rel_position (late=halluc) | 0.609 |

## Table: E5 abstention on POPE (band 20-27 chosen on dev; thresholds keep 80% of dev questions)

| Split | Acc (all) | Signal | AUROC (wrong) | Area under acc-coverage | Coverage @ dev thr | Acc @ dev thr |
|---|---|---|---|---|---|---|
| dev_random | 91.5 | image attention | 0.597 | 93.7 | 79.9 | 92.8 |
| dev_random | 91.5 | answer confidence | 0.870 | 98.3 | 79.9 | 97.1 |
| dev_random | 91.5 | random | 0.571 | 93.5 | - | - |
| random | 88.4 | image attention | 0.589 | 91.3 | 79.5 | 89.7 |
| random | 88.4 | answer confidence | 0.821 | 96.6 | 74.7 | 94.9 |
| random | 88.4 | random | 0.497 | 88.4 | - | - |
| popular | 87.5 | image attention | 0.574 | 90.4 | 76.9 | 88.5 |
| popular | 87.5 | answer confidence | 0.798 | 95.6 | 69.6 | 94.4 |
| popular | 87.5 | random | 0.489 | 87.0 | - | - |
| adversarial | 86.1 | image attention | 0.570 | 88.8 | 77.0 | 87.1 |
| adversarial | 86.1 | answer confidence | 0.779 | 94.5 | 64.7 | 93.7 |
| adversarial | 86.1 | random | 0.500 | 86.1 | - | - |

Caption filter (drop object mentions with low image attention, band 6-13, thresholds from dev):

| Mentions kept (dev quantile) | CHAIR-s | CHAIR-i | Recall |
|---|---|---|---|
| 1.0 | 35.0 | 7.8 | 71.3 |
| 0.9 | 32.6 | 7.4 | 70.8 |
| 0.8 | 30.6 | 7.3 | 69.7 |

## Table: E6 failure cases by heuristic cause

| Benchmark / kind | Causes |
|---|---|
| CHAIR introduced | co-occurrence: 48, other: 30, late in caption: 23 |
| CHAIR persistent | other: 56, co-occurrence: 43, late in caption: 10 |
| POPE-adversarial still | small object: 249, other: 99, co-occurrence: 54 |
| POPE-adversarial worse | small object: 21, other: 4, co-occurrence: 3 |
| POPE-popular still | small object: 249, other: 79, co-occurrence: 29 |
| POPE-popular worse | small object: 21, co-occurrence: 3, other: 1 |
| POPE-random still | small object: 249, other: 83, co-occurrence: 4 |
| POPE-random worse | small object: 21, other: 3 |

## E6 hand check of CHAIR hallucination labels

Random sample (random.seed(0); random.sample of the 341 CHAIR-hallucinated mentions in results/chair/baseline/chair_test_scored.jsonl, in file order) of 30 mentions, labelled by reading the caption context only (not the image). Labels were proposed by Claude and must be checked by the team.

scoring artefact: 18; possible real hallucination (or missing annotation): 12

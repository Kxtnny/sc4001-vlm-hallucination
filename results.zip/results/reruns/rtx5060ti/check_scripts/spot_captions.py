"""Regenerate the FIRST n images of chair_test (same batches of 8 as the original full run).

The CLI's --limit draws a random subset, which changes batch composition (and so, in bf16,
can change greedy outputs). The full run batched images in file order, so the first n
images (n a multiple of 8) form exactly the original first n/8 batches.

usage: python spot_captions.py <repo> <tag> <n> <alpha> <layers>
writes $SC4001_RESULTS/chair/<tag>/chair_test.jsonl (same record format as caption_chair.py)
"""
import sys
from pathlib import Path

repo = Path(sys.argv[1])
sys.path.insert(0, str(repo / "src"))
tag, n, alpha, layers = sys.argv[2], int(sys.argv[3]), float(sys.argv[4]), sys.argv[5]

from tqdm import tqdm  # noqa: E402

from halluc import config  # noqa: E402
from halluc.data import load_image, load_split  # noqa: E402
from halluc.io_utils import JsonlWriter  # noqa: E402
from halluc.model import VLM  # noqa: E402

images = load_split("chair_test")["images"][:n]
out = config.RESULTS_DIR / "chair" / tag
out.mkdir(parents=True, exist_ok=True)
vlm = VLM()
vlm.boost_mode = "post"
bs = config.CAPTION_BATCH_SIZE
with JsonlWriter(out / "chair_test.jsonl") as w:
    for i in tqdm(range(0, len(images), bs)):
        batch = images[i:i + bs]
        outs = vlm.generate_batch([load_image(im) for im in batch], [config.CAPTION_PROMPT] * len(batch),
                                  max_new_tokens=config.CAPTION_MAX_NEW_TOKENS, alpha=alpha, layers=layers)
        for im, (cap, ids) in zip(batch, outs):
            w.write({"image": im, "caption": cap, "token_ids": ids, "n_new_tokens": len(ids),
                     "alpha": alpha, "layers": layers})
